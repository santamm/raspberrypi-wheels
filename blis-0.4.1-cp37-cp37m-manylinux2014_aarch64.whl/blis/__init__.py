# Copyright ExplsionAI GmbH, released under BSD.

from .cy import init

init()
